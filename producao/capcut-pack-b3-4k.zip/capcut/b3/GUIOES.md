# Semanas 1-2 — Guiões de produção (v5 · identidade B3 Terminal Humano)
### 6 vídeos · overlays B3 4K prontos no pacote (pasta b3/overlays) · QC visual feito

**Identidade B3 — regras nos vídeos:** painéis escuros arredondados, números em mono menta (#7FE3B4), vermelho-suave (#FF8C7A) SÓ para perdas, e a camada-assinatura: **cada dado tem a tradução humana por baixo**. Etiqueta de fonte (chip escuro, valor em menta) sempre que há dados no ecrã, canto inferior-esquerdo. Zero brilhos neon, cortes secos. Modo B4 Wire (âmbar + fita ticker) reservado a dados acabados de publicar — não se usa nestas duas semanas.

**Ordem de publicação:** S1: #1 (estreia) → #39 → #31 · S2: #7 → #19 → #23
**Ordem de gravação em batch:** #31 → #39 → #7 → #23 → #19 → #1 (a estreia por último, já quente)

---

# S1·V1 — "44,7% não pagou IRS" (#1) · 46-48s

| ⏱ | 🎙 Fala | 📺 Overlay |
|---|---|---|
| 0-3s | "Quase metade dos agregados que entregaram IRS em Portugal não pagou um cêntimo de imposto em 2024." | `v01-1-hook.png` (painel 44,7% + "quase metade das declarações") + `fonte-at` |
| 3-9s | "E isto não é uma boa notícia. Também não é bem o que parece." | `v01-2-tensao.png` aos 4,5s |
| 9-15s | "Em 2024 foram entregues 6,2 milhões de declarações. Só 3,4 milhões pagaram imposto. Os outros quase três milhões dividem-se em três grupos." *(três dedos)* | `v01-3-funil.png` + `fonte-at` |
| 15-20s | "Primeiro: rendimentos demasiado baixos para gerar imposto — cerca de 1 em cada 4 trabalhadores ganha o salário mínimo, e muitas pensões ficam abaixo do limiar." | `v01-4-causa1.png` + `fonte-at` |
| 20-26s | "Segundo: quem declara tudo, mas as deduções e benefícios anulam o imposto — IRS Jovem, saúde, educação, dependentes. É o próprio sistema a zerar a conta." | `v01-5-causa2.png` |
| 26-32s | "E terceiro: rendimento que existe, mas nunca chega à declaração. O mínimo na folha, o resto por fora." *(tom desce — gancho p/ #39)* | `v01-6-causa3.png` |
| 32-42s | "Três realidades dentro do mesmo número. E a parte desconfortável: a AT não publica quanto pesa cada grupo. Ninguém sabe ao certo." *(plano mais fechado; 32-36s SEM overlay)* | `v01-7-reframe.png` só aos 36s |
| 42-47s | "Qual dos três achas que pesa mais? No próximo vídeo mostro o que se sabe — e o que não se sabe — sobre o terceiro." | `v01-8-cta.png` |

**Rigor:** "agregados que entregaram declaração", nunca "famílias". Promessa do CTA cumpre-se: #39 é o vídeo seguinte. Descrição + 📌 Nota de rigor: no storyboard.

---

# S1·V2 — "Economia paralela: o número que ninguém sabe" (#39) · 45-50s

| ⏱ | 🎙 Fala | 📺 Overlay |
|---|---|---|
| 0-3s | "Quanto vale a economia por fora em Portugal? Fui ver os estudos. Quatro estudos sérios, quatro respostas completamente diferentes." | `v39-1-hook.png` (9% a 34%) + `fonte-estudos` |
| 3-9s | "E o facto de ninguém saber ao certo é, em si mesmo, a parte mais interessante." | `v39-2-tensao.png` |
| 9-28s | "A EY estima 9,3% do PIB. Schneider, a referência internacional, diz 17% — uns 44 mil milhões. O CEPR aponta 24% — pódio europeu, atrás da Grécia e Itália. E a Faculdade de Economia do Porto calcula 34,4% — mais de 80 mil milhões." | `v39-3-estimativas.png` (4 barras) + `fonte-estudos` |
| 28-34s | "Repara: mesmo a estimativa mais baixa são mais de 25 mil milhões por ano fora do radar. Quem te der um valor exato com certeza absoluta está a inventar." | `v39-4-payload2.png` |
| 34-42s | "E dentro deste bolo cabe de tudo: do biscate de quem não chega ao fim do mês à fraude organizada de quem chega muito bem. Não é tudo a mesma coisa." | `v39-5-reframe.png` |
| 42-48s | "Das quatro estimativas, qual te parece mais próxima da realidade que conheces?" | `v39-6-cta.png` |

**Rigor:** 4 estimativas com fonte e ano — ⚠️ reconfirmar todas antes de gravar. Nunca eleger uma como "a verdadeira".

---

# S1·V3 — "202 mil milhões a derreter" (#31) · 46-50s

| ⏱ | 🎙 Fala | 📺 Overlay |
|---|---|---|
| 0-3s | "As famílias portuguesas têm duzentos e dois mil milhões de euros parados no banco. Um recorde histórico." | `v31-1-hook.png` (dígitos completos) + `fonte-bdp` |
| 3-9s | "Parece uma boa notícia — um país de aforradores. Vamos fazer a conta que os bancos não fazem por ti." | `v31-2-tensao.png` |
| 9-20s | "Este dinheiro divide-se: uns 90 mil milhões à ordem, a render praticamente zero. E uns 112 mil milhões a prazo, a render em média 1,4%. A inflação está nos 2,2%." | `v31-3-depositos.png` + `fonte-bdp` |
| 20-30s | "O dinheiro à ordem perde a inflação inteira: uns dois mil milhões por ano. O a prazo perde a diferença: mais uns novecentos milhões." | `v31-4-perdas.png` + `fonte-ine` |
| 30-36s | "Somados: perto de três mil milhões de euros de poder de compra que evaporam todos os anos. Sem ninguém roubar nada." | `v31-5-resultado.png` |
| 36-43s | "O extrato sobe, a riqueza desce. E poupar é o instinto certo — o que falta é o passo seguinte. Nem os produtos 'garantidos' resolvem isto. Fica para outro vídeo desta série." | `v31-6-reframe.png` |
| 43-48s | "O teu dinheiro está à ordem ou a prazo? A resposta muda quanto estás a perder." | `v31-7-cta.png` |

**Rigor:** ⚠️ reconfirmar no dia: stock e divisão (BdP), juro médio dos novos depósitos, última inflação homóloga (INE). Premissas ditas em voz alta.

---

# S2·V1 — "A conta que quase ninguém fez" (#7) · 42-46s

| ⏱ | 🎙 Fala | 📺 Overlay |
|---|---|---|
| 0-3s | "Se estás no escalão dos trinta e cinco por cento... provavelmente pagas vinte e um." | `v07-1-hook.png` (34,9% → ~21%) + `fonte-at` |
| 3-8s | "E a diferença entre os dois números explica-se em vinte segundos, com a tabela das Finanças." | `v07-2-tensao.png` |
| 8-20s | "O teu rendimento não é tributado todo à mesma taxa. É cortado em fatias — nove. A primeira, até 8.342 euros, paga 12,5%. Sempre. E quando sobes de escalão, só o dinheiro acima da linha paga a taxa nova." | `v07-3-fatias.png` + `fonte-at` |
| 20-30s | "Com 30 mil euros de rendimento coletável — atenção, coletável, depois das deduções — o escalão diz 34,9%. A taxa que efetivamente pagas anda nos 21%." | `v07-4-resultado.png` + `fonte-at` |
| 30-38s | "Consequência prática: um aumento nunca te faz receber menos ao fim do mês. Há quem recuse aumentos por esse medo — a matemática diz que não é preciso." | `v07-5-reframe.png` |
| 38-44s | "Já tinhas feito esta conta? A diferença entre marginal e efetiva é das coisas mais úteis que ninguém ensina." | `v07-6-cta.png` |

**Rigor:** taxas 2026 (9 escalões; 1.º até 8.342€ a 12,5%; 30k coletável → ~20,9% efetiva). Dizer "coletável" em voz alta. Desde 2023 a retenção mensal é marginal — a frase do aumento vale também para o líquido mensal.

---

# S2·V2 — "O pior inimigo do teu dinheiro" (#19 · piloto psicologia) · 42-46s

| ⏱ | 🎙 Fala | 📺 Overlay |
|---|---|---|
| 0-3s | "O pior inimigo do teu dinheiro não é a inflação. Nem os impostos. És tu." | `v19-1-hook.png` |
| 3-8s | "E isto não é um insulto — é um padrão documentado há décadas. Deixa-me mostrar-te o ciclo." | *(sem overlay — só tu)* |
| 8-22s | "Quando os mercados sobem e toda a gente fala nisso, sentimos confiança — e compramos. No topo. Quando caem e as notícias assustam, sentimos pânico — e vendemos. No fundo. Compramos caro e vendemos barato: exatamente o contrário do objetivo." | `v19-2-ciclo.png` (curva) |
| 22-30s | "O medo e a ganância trocam-te os preços: a queda que devia parecer desconto parece perigo, e a euforia que devia parecer perigo parece oportunidade." | `v19-3-payload.png` |
| 30-38s | "A defesa não é seres mais frio do que os outros. É decidires ANTES da tempestade: um plano automático que investe todos os meses, faça o mercado o que fizer — para a decisão nunca ser tomada com medo." | `v19-4-reframe.png` |
| 38-44s | "Já te apanhaste a fazer isto? Sê honesto nos comentários — eu já." | `v19-5-cta.png` |

**Rigor:** o guião deliberadamente NÃO cita números (o "behavior gap" da DALBAR/Morningstar tem críticas metodológicas) — descreve o padrão, que é consensual em finanças comportamentais. ⚠️ Se quiseres citar um valor, verificamos juntos antes. O "eu já" final: confissão pessoal = confiança.

---

# S2·V3 — "O preço real da proteína" (#23 · treino×finanças) · 42-46s

| ⏱ | 🎙 Fala | 📺 Overlay |
|---|---|---|
| 0-3s | "Estás a pagar até três vezes mais pela mesma proteína. E o rótulo diz-to — em letras pequenas." | `v23-1-hook.png` + `fonte-precos` |
| 3-8s | "O marketing vende-te 'HIGH PROTEIN' na capa. A matemática, lá atrás, vende-te outra coisa." | *(segurar um produto real — o adereço É a história)* |
| 8-22s | "Fiz a conta que interessa: o custo por vinte gramas de proteína. Ovos: cêntimos. Whey — sim, o suplemento — mais barato que muita comida. E as barritas 'proteicas'? Podem custar quatro vezes os ovos, pela mesma proteína." | `v23-2-ranking.png` + `fonte-precos` |
| 22-30s | "A regra que se repete: quanto mais a embalagem grita PROTEIN, mais estás a pagar pelo grito." | `v23-3-payload.png` |
| 30-38s | "Lê o rótulo como lês um extrato bancário: ignora a capa, procura o número. Gramas de proteína a dividir pelo preço — é a única linha que importa." | `v23-4-reframe.png` |
| 38-44s | "Qual é a tua fonte habitual de proteína? Diz nos comentários e eu digo-te se estás a pagar o justo." | `v23-5-cta.png` |

**Rigor CRÍTICO:** ⚠️ os valores do ranking são EXEMPLO — no dia: ir ao supermercado, registar preços reais (fotos → stories como prova), enviar-me os valores → **regenero o PNG em minutos** com os preços verdadeiros e a etiqueta com a data. O vídeo não sai com o cartão de exemplo. Tom: whey não é vilão nem herói — é só €/proteína.

---

## Checklist por vídeo
- [ ] Números reconfirmados na fonte no dia (⚠️ de cada guião)
- [ ] Overlays a 100% de escala, cortes secos, etiqueta de fonte quando há dados
- [ ] Registo: cortar qualquer frase que um influencer diria e um profissional não
- [ ] Ver SEM SOM do início ao fim antes de exportar
- [ ] Exportar 4K → descrição (1.ª linha = 2.º hook) → 📌 Nota de rigor fixada → 60 min de comentários
- [ ] Dashboard: estado + métricas → ⬇ performance.json → commit → linha no learnings.md
